$(document).load(function(){
	new WOW().init();
	
	
});
